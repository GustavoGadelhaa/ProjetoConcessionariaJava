class Idoso extends Pessoa {
    private int idade;

    public Idoso(String nome, String cpf, String numeroContato, int idade) {
        super(nome, cpf, numeroContato);
        this.idade = idade;
    }

    public int getIdade() {
        return idade;
    }
}
