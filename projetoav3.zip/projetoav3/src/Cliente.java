public abstract class Cliente extends Pessoa {
    public Cliente(String nome, String cpf, String numeroContato) {
        super(nome, cpf, numeroContato);
    }
}
