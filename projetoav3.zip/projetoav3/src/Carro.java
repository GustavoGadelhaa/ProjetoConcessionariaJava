public abstract class Carro extends Veiculo {
    public Carro(String modelo, double preco) {
        super(modelo, preco);
    }
}