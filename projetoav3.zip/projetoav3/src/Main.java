import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        CarrosDisponiveis carrosDisponiveis = new CarrosDisponiveis();

        carrosDisponiveis.mostrarCarrosDisponiveis();

        int opcao = 0;
        while (opcao != 5) {
            exibirMenu();
            opcao = entrada.nextInt();

            try {
                if (opcao == 1) {
                    registrarCliente(entrada, carrosDisponiveis);
                } else if (opcao == 2) {
                    carrosDisponiveis.exibirClientesCadastrados();
                } else if (opcao == 3) {
                    carrosDisponiveis.exibirCarrosDisponiveis();
                } else if (opcao == 4) {
                    alugarCarro(entrada, carrosDisponiveis);
                } else if (opcao == 5) {
                    System.out.println("Saindo do programa...");
                } else {
                    System.out.println("Opção inválida. Tente novamente.");
                }
            } catch (CarroAluguelException e) {
                System.out.println("Erro: " + e.getMessage());
            }

            System.out.println();
        }
        entrada.close();
    }

    private static void exibirMenu() {
        System.out.println("===== MENU =====");
        System.out.println("1. Registrar cliente");
        System.out.println("2. Exibir clientes cadastrados");
        System.out.println("3. Exibir carros disponíveis");
        System.out.println("4. Alugar carro");
        System.out.println("5. Sair");
        System.out.print("Escolha uma opção: ");
    }

    private static void registrarCliente(Scanner entrada, CarrosDisponiveis carrosDisponiveis) {
        System.out.println("===== REGISTRO DE CLIENTE =====");
        entrada.nextLine();

        System.out.print("Digite o nome do cliente: ");
        String nomeCliente = entrada.nextLine();
        System.out.print("Digite o CPF do cliente: ");
        String cpfCliente = entrada.nextLine();
        System.out.print("Digite o número de contato do cliente: ");
        String numeroContato = entrada.nextLine();

        int numeroCliente = carrosDisponiveis.cadastrarCliente(nomeCliente, cpfCliente, numeroContato);

        System.out.println("Registro efetuado com sucesso. Número do cliente: " + numeroCliente);
    }

    private static void alugarCarro(Scanner entrada, CarrosDisponiveis carrosDisponiveis) throws CarroAluguelException {
        System.out.print("Digite o número do cliente: ");
        int numeroCliente = entrada.nextInt();

        if (numeroCliente >= 1 && numeroCliente <= carrosDisponiveis.getQuantidadeClientes()) {
            Cliente cliente = carrosDisponiveis.getCliente(numeroCliente - 1);
            System.out.println("Cliente selecionado: " + cliente.getNome());

            System.out.println();
            carrosDisponiveis.exibirCarrosDisponiveis();

            System.out.print("Digite o número do carro que deseja alugar: ");
            int numeroCarro = entrada.nextInt();

            if (numeroCarro >= 1 && numeroCarro <= carrosDisponiveis.getQuantidadeCarros()) {
                Carro carro = carrosDisponiveis.getCarro(numeroCarro - 1);
                System.out.println("Carro selecionado para aluguel: " + carro.getModelo());

                System.out.print("Digite o método de pagamento (1 - Dinheiro, 2 - Cartão): ");
                int metodoPagamento = entrada.nextInt();

                if (metodoPagamento == 1 || metodoPagamento == 2) {
                    String metodoPagamentoStr = (metodoPagamento == 1) ? "Dinheiro" : "Cartão";

                    System.out.println("Carro alugado com sucesso!");
                    System.out.println("Detalhes da compra:");
                    System.out.println("Cliente: " + cliente.getNome());
                    System.out.println("Carro alugado: " + carro.getModelo());
                    System.out.println("Preço: R$ " + carro.getPreco());
                    System.out.println("Método de pagamento: " + metodoPagamentoStr);
                } else {
                    throw new CarroAluguelException("Método de pagamento inválido.");
                }
            } else {
                throw new CarroAluguelException("Número do carro inválido.");
            }
        } else {
            throw new CarroAluguelException("Número do cliente inválido.");
        }
    }
}
