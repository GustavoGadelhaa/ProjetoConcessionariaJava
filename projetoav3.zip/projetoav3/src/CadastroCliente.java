import java.util.Scanner;

public interface CadastroCliente {
    void registrarCliente(Scanner entrada, CarrosDisponiveis carrosDisponiveis);
}