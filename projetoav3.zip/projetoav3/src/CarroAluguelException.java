public class CarroAluguelException extends Exception {
    public CarroAluguelException(String message) {
        super(message);
    }
}
