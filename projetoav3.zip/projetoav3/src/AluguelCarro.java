import java.util.Scanner;

public interface AluguelCarro {
    void alugarCarro(Scanner entrada, CarrosDisponiveis carrosDisponiveis) throws CarroAluguelException;
}
