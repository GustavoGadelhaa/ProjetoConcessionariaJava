public interface ExibicaoInformacoes {
    void exibirClientesCadastrados();
    void exibirCarrosDisponiveis();
}



