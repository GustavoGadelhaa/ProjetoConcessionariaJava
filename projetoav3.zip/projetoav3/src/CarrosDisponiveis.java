import java.util.ArrayList;
import java.util.List;

public class CarrosDisponiveis {
    private List<Cliente> clientes;
    private List<Carro> carros;

    public CarrosDisponiveis() {
        clientes = new ArrayList<>();
        carros = new ArrayList<>();
    }

    public int cadastrarCliente(String nome, String cpf, String numeroContato) {
        Cliente cliente = new ClienteX(nome, cpf, numeroContato);
        clientes.add(cliente);
        return clientes.size();
    }

    public void exibirClientesCadastrados() {
        System.out.println("Clientes cadastrados:");
        for (Cliente cliente : clientes) {
            System.out.println(cliente.getNome() + " - " + cliente.getCpf() + " - " + cliente.getNumeroContato());
        }
    }

    public void exibirCarrosDisponiveis() {
        System.out.println("Carros disponíveis:");
        for (int i = 0; i < carros.size(); i++) {
            Carro carro = carros.get(i);
            System.out.println((i + 1) + ". " + carro.getModelo() + " - R$ " + carro.getPreco());
        }
    }

    public int getQuantidadeClientes() {
        return clientes.size();
    }

    public Cliente getCliente(int index) {
        return clientes.get(index);
    }

    public int getQuantidadeCarros() {
        return carros.size();
    }

    public Carro getCarro(int index) {
        return carros.get(index);
    }

    public void mostrarCarrosDisponiveis() {
        carros.add(new CarroX("Ford Ka - DIARIA", 350));
        carros.add(new CarroX("Gol - DIARIA", 300));
        carros.add(new CarroX("Onix - DIARIA", 400));
        carros.add(new CarroX("Hilux - DIARIA", 850));
    }

    private static class ClienteX extends Cliente {
        public ClienteX(String nome, String cpf, String numeroContato) {
            super(nome, cpf, numeroContato);
        }
    }

    private static class CarroX extends Carro {
        public CarroX(String modelo, double preco) {
            super(modelo, preco);
        }
    }
}
