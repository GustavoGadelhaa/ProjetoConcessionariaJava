public class ClienteEspecial extends Cliente {
    private int nivel;

    public ClienteEspecial(String nome, String cpf, String numeroContato, int nivel) {
        super(nome, cpf, numeroContato);
        this.nivel = nivel;
    }

    public int getNivel() {
        return nivel;
    }
}
