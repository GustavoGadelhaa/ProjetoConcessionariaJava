public abstract class Pessoa {
    private String nome;
    private String cpf;
    private String numeroContato;

    public Pessoa(String nome, String cpf, String numeroContato) {
        this.nome = nome;
        this.cpf = cpf;
        this.numeroContato = numeroContato;
    }

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public String getNumeroContato() {
        return numeroContato;
    }
}
